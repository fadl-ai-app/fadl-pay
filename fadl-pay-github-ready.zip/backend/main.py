"""
Fadl Pay
Core Backend
Sandbox / Prototype
"""

from fastapi import FastAPI

app = FastAPI(
    title="Fadl Pay API",
    description="Payment Gateway Infrastructure - Sandbox",
    version="0.1.0",
)


@app.get("/")
def root():
    return {
        "name": "Fadl Pay",
        "status": "sandbox",
        "version": "0.1.0",
        "message": "Fadl Pay API is running"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "environment": "sandbox"
    }

from backend.api import app as api_app

app.mount("/", api_app)


# Merchant Dashboard Integration
from app.merchant_dashboard import create_dashboard
